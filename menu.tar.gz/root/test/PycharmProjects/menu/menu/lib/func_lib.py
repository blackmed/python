#!/usr/bin/env python3
# coding=utf-8

import time

def timer():
    print(time.strftime('%Y-%m-%d %X'))

def f31():
    print('this is f31')

def f32():
    print('this is f32')

def f3():
    print('this is f3')