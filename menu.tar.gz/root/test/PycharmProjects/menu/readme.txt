
程序入口在menu/bin/run.py
运行run.py就可以运行整个程序
